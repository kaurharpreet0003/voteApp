import java.util.Scanner;

class Palindrome {

    private static Scanner scanner = new Scanner(System.in);

    public static void main (String[] args) {
        System.out.print("Enter a phrase : ");
        String original = scanner.nextLine();

        // We store just the alphabetic letters
        String temp = "";
        for (int i = 0; i < original.length(); i++) {
            char c = original.charAt(i);
            if (Character.isLetter(c)) {
                temp += c;
            }
        }

        // convert to lowercase
        String test = temp.toLowerCase();

        // Test
        int leftPos = 0;
        int rightPos = test.length() - 1;
        boolean palindrome=true;

        while ((leftPos < rightPos) && palindrome) {
            palindrome = test.charAt(leftPos) == test.charAt(rightPos);
            leftPos++;
            rightPos--;
        }

        if (palindrome) {
            System.out.println("It is palindrome !");
        } else {
            System.out.println("Nop, it is not palindrome.");
        }
    }
}
