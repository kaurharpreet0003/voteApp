import java.util.Scanner;

class MulMat {
    public static void main(String[] args) { 
        Scanner scanner = new Scanner(System.in);
        int rows = 0;
        int columns = 0;

        // registering the first matrix
        System.out.println("registering the first matrix :");
        // verifying if the number of rows is greater than 0 
        while (rows < 1) { 
            System.out.print("Number of rows : ");
            rows = scanner.nextInt();
        }
        // verifying if the number of columns is greater than 0
        while (columns < 1) {
            System.out.print("Number of columns : ");
            columns = scanner.nextInt();
        }
        // Declaration-construction of the first matrix
        double[][] mat1 = new double[rows][columns];
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                System.out.print(" M[" + (row + 1) + "," + (col + 1) + "]=");
                mat1[row][col] = scanner.nextDouble();
            }
        }
        // ... the same for the second matrix
        rows = 0; columns = 0;
        System.out.println("Registering the 2nd matrix :");
        while (rows < 1) {
            System.out.print("Number of rows : ");
            rows = scanner.nextInt();
        }
        while (columns < 1) {
            System.out.print("Number de columns : ");
            columns = scanner.nextInt();
        }
        double[][] mat2 = new double[rows][columns];
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < columns; col++) {
                System.out.print(" M[" + (row + 1) + "," + (col + 1) + "]=");
                mat2[row][col] = scanner.nextDouble();
            }
        }
        // multiplying the two matrix
        if (mat1[0].length != mat2.length) {
            System.out.println("Multiplication of matrices is impossible !");
        } else {
            // Declaration-Construction of the result matrix
            double[][] prod = new double[mat1.length][mat2[0].length];
            for (int row = 0; row < mat1.length; row++) {
                for (int col = 0; col < mat2[0].length; col++) {
                    prod[row][col] = 0.0;
                    for (int i = 0; i < mat2.length; i++) {
                        prod[row][col] += mat1[row][i] * mat2[i][col];
                    }
                }
            }
            // Displaying the result
            System.out.println("Result :");
            for (int row = 0; row < prod.length; row++) {
                for (int col = 0; col < prod[row].length; col++) {
                    System.out.print(prod[row][col] + " ");
                }
                System.out.println();
            }
    }
    scanner.close();
    }
}