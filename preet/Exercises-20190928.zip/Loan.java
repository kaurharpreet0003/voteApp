import java.util.Scanner;

public class Loan {
    private static Scanner keyboard = new Scanner(System.in);

    public static void main(String[] args) {
        double s0 = 0.0;
        do {
            System.out.print("Loan borrowed (S0 > 0) : ");
            s0 = keyboard.nextDouble();
        } while (s0 <= 0.0);

        double r = 0.0;
        do {
            System.out.println("fixed amount reimbursing each month (r > 0) :");
            r = keyboard.nextDouble();
        } while (r <= 0.0);

        double ir = 0.0;
        do {
            System.out.println("interest rate in % (0 < tx < 100) : ");
            ir = keyboard.nextDouble();
        } while ((ir < 0) || (ir > 100));
        // converting to percent
        ir /= 100.00;

        double sumInterest = 0.0;
        int nbr = 0; // number of reimbursements

        for (double s = s0; s > 0.0; s -= r) {
            // s : remaining amount for the reimbursement
            ++nbr;
            sumInterest += ir * s;
            System.out.println(nbr + ": s=" + s + ", sumInterest = " + sumInterest);
        }
        System.out.println("The sum of interests received : " + sumInterest + " (over " + nbr + " months).");


    }
}
