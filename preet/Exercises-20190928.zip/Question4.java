import java.util.Scanner;

public class Question4 {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("How much did you receive money?");
        double myMoney = keyboard.nextDouble();
        double tuition = myMoney * 3/4.0;
        System.out.println("Books and supplies : " + tuition);
        System.out.println("You can then buy :");
        double restMoney = myMoney - tuition;
        double balanceForEach = restMoney / 3.0;
        int numCoffee = (int) balanceForEach / 2;
        System.out.println(numCoffee + " Coffees");
        int numFlash = (int) balanceForEach / 3;
        System.out.println(numFlash + " Flash Memories");
        int numTickets = (int) balanceForEach / 4;
        System.out.println(numTickets + " Tickets");
        double remainder = restMoney - (numCoffee * 2 + numFlash * 3 + numTickets * 4);
        System.out.println("And you will have " + remainder + " dollars to buy flowers");



    }
}
