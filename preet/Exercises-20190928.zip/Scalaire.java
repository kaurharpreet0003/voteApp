import java.util.Scanner;

class Scalaire {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nMax = 10; int n = 0;

        while (n < 1 || n > nMax) {
            System.out.print("What size for your vectors [between 1 and "
                    + nMax + "] ? ");
            n = scanner.nextInt();
        }
        // declaration-construction of two vectors
        double [] v1 = new double [n];
        double [] v2 = new double [n];
        System.out.println("Registering the first vector :");
        for (int i = 0; i < n; i++) {
            System.out.print(" v1[" + i + "] = ");
            v1[i] = scanner.nextDouble();
        }
        System.out.println("Registering the second vector :");
        for (int i = 0; i < n; i++) {
            System.out.print(" v2[" + i + "] = ");
            v2[i] = scanner.nextDouble();
        }
        // Calculation of the scalar product
        double sum = 0.0;
        for (int i = 0; i < v1.length; i++) {
            sum += v1[i] * v2[i]; }
        System.out.println("The scalar product of v1 and v2 is " + sum);
        scanner.close();
    }
}
    