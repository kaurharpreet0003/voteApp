public class TestCircle {

    public static void main(String[] args) {
        Circle c1 = new Circle(); Circle c2 = new Circle(); Circle c3 = new Circle();
        c1.setCentre(1.0, 2.0); c1.setRadius(Math.sqrt(5.0));
        c2.setCentre(-2.0, 1.0); c2.setRadius(2.25); // 2.25 > sqrt(5)
        c3.setCentre(-2.0, -5.0); c3.setRadius(1.0);
        System.out.println("Surface area of c1 : " + c1.surface());
        System.out.println("Surface area of c2 : " + c2.surface());
        System.out.println("Surface area of c3 : " + c3.surface());
        displayPosition("c1", c1, 0.0, 0.0);
        displayPosition("c2", c2, 0.0, 0.0);
        displayPosition("c3", c3, 0.0, 0.0);
    }

    static void displayPosition(String name, Circle c, double x, double y) {
        System.out.print("Position of point (" + x + ", " + y + ") : ");
        if (c.isInternal(x,y))
            System.out.print("inside ");
        else
            System.out.print("outside of ");
        System.out.println(name); 
    }
}
/* Class Circle */
class Circle {
    private double radius;
    private double x;
    double y;
    // surface area of circle
    public double surface() { return Math.PI * radius * radius; }

    public boolean isInternal(double unX, double unY) {
        return (((unX-x) * (unX-x) +
                (unY-y) * (unY-y))
                <= radius * radius);
    }
    public void setCentre(double unX, double unY) {
        x = unX;
        y = unY;
    }
    public void setRadius(double r) {
        if (r < 0.0)
            r = 0.0;
        radius = r;
    }
}